#include <windows.h>
#include <cmath>
#include <thread>

// 1. Função de Círculos com Inversão (Lente)
void ci(int x, int y, int w, int h) {
    HDC hdc = GetDC(0);
    // Cria uma região elíptica para limitar o desenho
    HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
    SelectClipRgn(hdc, hrgn);

    // Inverte apenas a área dentro do círculo
    BitBlt(hdc, x, y, w, h, hdc, x, y, NOTSRCCOPY);

    DeleteObject(hrgn);
    ReleaseDC(NULL, hdc);
}

// Thread para disparar os círculos aleatórios
void CirclesThread() {
    int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    while (true) {
        ci(rand() % sw, rand() % sh, 150, 150);
        Sleep(100);
    }
}

// 2. Payload: Cilindro RGB Deformável (Estilo DVD Logo)
void RGBCylinderDVD() {
    int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    int x = 200, y = 200;       // Posição inicial
    int dx = 8, dy = 8;         // Velocidade
    int cw = 200, ch = 300;     // Dimensões do cilindro
    float angle = 0;            // Para a animação de rotação/deformação

    while (true) {
        HDC hdc = GetDC(0);
        angle += 0.1f;

        // Desenha o cilindro linha por linha para criar o efeito RGB e volume
        for (int i = 0; i < cw; i++) {
            // Cálculo de cor senoidal (efeito arco-íris)
            int r = (int)(127 + 127 * sin(angle + i * 0.05));
            int g = (int)(127 + 127 * sin(angle + i * 0.05 + 2));
            int b = (int)(127 + 127 * sin(angle + i * 0.05 + 4));

            // Deformação senoidal na altura (efeito "onda")
            int deform = (int)(20 * sin(angle + i * 0.1));

            HPEN hPen = CreatePen(PS_SOLID, 2, RGB(r, g, b));
            SelectObject(hdc, hPen);

            // Desenha a linha vertical do cilindro
            MoveToEx(hdc, x + i, y + deform, NULL);
            LineTo(hdc, x + i, y + ch + deform);

            DeleteObject(hPen);
        }

        // Movimentação estilo DVD
        x += dx; y += dy;
        if (x <= 0 || x + cw >= sw) dx = -dx;
        if (y <= 0 || y + ch >= sh) dy = -dy;

        ReleaseDC(0, hdc);
        Sleep(15);
    }
}

int main() {
    ShowWindow(GetConsoleWindow(), SW_HIDE);

    // Inicia os efeitos em paralelo
    std::thread t1(CirclesThread);
    std::thread t2(RGBCylinderDVD);

    t1.join();
    t2.join();

    return 0;
}
