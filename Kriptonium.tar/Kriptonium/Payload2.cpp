#include <windows.h>

// Função para o Bytebeat Visual (Corrupção de Pixels)
DWORD WINAPI BytebeatPayload(LPVOID lpParam) {
    int ticks = GetTickCount();
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);

    // Aloca memória para os pixels da tela
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);

    for (int i = 0;; i++, i %= 3) {
        HDC hdc = GetDC(0);
        HDC hdcMem = CreateCompatibleDC(hdc);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);

        SelectObject(hdcMem, hbm);
        BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, w * h * 4, data);

        int v = 0;
        BYTE bt = 0;

        // Após 1 minuto, o efeito muda de intensidade
        if ((GetTickCount() - ticks) > 60000) bt = rand() & 0xffffff;

        for (int j = 0; w * h > j; j++) {
            if (j % h == 0 && rand() % 100 == 0) v = rand() % 50;
            // Operação aritmética nos bytes da imagem
            ((BYTE*)(data + j))[v ? 252 : 252] += ((BYTE*)(data + j))[j % 3] ^ bt;
        }

        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(hdc, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);

        // Limpeza de objetos para evitar Memory Leak (vazamento de memória)
        DeleteObject(hbm);
        DeleteDC(hdcMem);
        ReleaseDC(0, hdc);

        Sleep(10); // Adicionado para não congelar o sistema totalmente
    }
}

// Função para o Inversor de Tela (Strobe)
DWORD WINAPI StrobePayload(LPVOID lpParam) {
    int x = GetSystemMetrics(0);
    int y = GetSystemMetrics(1);

    while (1) {
        HDC hdc = GetDC(0);
        // PATINVERT inverte as cores com base no padrão atual
        PatBlt(hdc, 0, 0, x, y, PATINVERT);
        ReleaseDC(0, hdc);
        Sleep(100);
    }
}

int main() {
    // Esconde o console
    ShowWindow(GetConsoleWindow(), SW_HIDE);

    // Cria as duas threads para rodar os efeitos ao mesmo tempo
    HANDLE thread1 = CreateThread(NULL, 0, BytebeatPayload, NULL, 0, NULL);
    HANDLE thread2 = CreateThread(NULL, 0, StrobePayload, NULL, 0, NULL);

    // Espera infinita
    WaitForSingleObject(thread1, INFINITE);

    return 0;
}