#include <windows.h>
#include <thread>

// 1. Payload do Derretimento Reverso (NOTSRCCOPY)
void ReverseMelt() {
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    while (1) {
        HDC hdc = GetDC(0);
        int x = rand() % w;
        // Inverte cores e desloca 1 pixel para baixo
        BitBlt(hdc, x, 1, 10, h, hdc, x, 0, NOTSRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(2);
    }
}

// 2. Payload Thing6 (PlgBlt e BitBlt com ROP 0x123456)
void Thing6() {
    while (1) {
        HDC hdc = GetDC(0);
        HDC hdcMem = CreateCompatibleDC(hdc);
        int sw = GetSystemMetrics(0);
        int sh = GetSystemMetrics(1);
        HBITMAP bm = CreateCompatibleBitmap(hdc, sw, sh);
        SelectObject(hdcMem, bm);

        RECT rect;
        GetWindowRect(GetDesktopWindow(), &rect);

        // PlgBlt rotaciona ou distorce a imagem com base em 3 pontos (paralelogramo)
        POINT pt[3];
        pt[0].x = rect.left + rand() % 20;  pt[0].y = rect.top + rand() % 20;
        pt[1].x = rect.right - rand() % 20; pt[1].y = rect.top + rand() % 20;
        pt[2].x = rect.left + rand() % 20;  pt[2].y = rect.bottom - rand() % 20;

        PlgBlt(hdcMem, pt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);

        HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
        SelectObject(hdc, brush);

        // Aplica o efeito usando o código de operação ternária 0x123456
        BitBlt(hdc, rand() % 20, rand() % 20, sw, sh, hdcMem, rand() % 20, rand() % 20, 0x123456);

        DeleteObject(brush);
        DeleteObject(bm);
        DeleteDC(hdcMem);
        ReleaseDC(0, hdc);
        Sleep(10); // Aumentado levemente para evitar crash instantâneo
    }
}

// 3. Payload Ícone de Pergunta (Estilo DVD Logo)
void QuestionDVDPayload() {
    int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    int x = 100, y = 100;
    int moveX = 10, moveY = 10;
    HICON hQuestion = LoadIcon(NULL, IDI_QUESTION);

    while (1) {
        HDC hdc = GetDC(0);

        // Desenha o ícone na posição atual
        DrawIcon(hdc, x, y, hQuestion);

        x += moveX;
        y += moveY;

        // Lógica de colisão para rebater nas bordas
        if (x <= 0 || x + 32 >= sw) moveX = -moveX;
        if (y <= 0 || y + 32 >= sh) moveY = -moveY;

        ReleaseDC(0, hdc);
        Sleep(20);
    }
}

int main() {
    // Esconde o console para o efeito ser direto na tela
    ShowWindow(GetConsoleWindow(), SW_HIDE);

    // Criando as threads para rodar tudo simultaneamente
    std::thread t1(ReverseMelt);
    std::thread t2(Thing6);
    std::thread t3(QuestionDVDPayload);

    // Mantém o processo ativo
    t1.join();
    t2.join();
    t3.join();

    return 0;
}