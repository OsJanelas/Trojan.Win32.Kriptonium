#include <windows.h>
#include <cmath>
#include <thread>
#include <vector>

// Estruturas de Cores
struct HSV { float h, s, v; };

HSV RGBtoHSV(RGBQUAD rgb) {
    float r = rgb.rgbRed / 255.0f, g = rgb.rgbGreen / 255.0f, b = rgb.rgbBlue / 255.0f;
    float max = fmaxf(fmaxf(r, g), b), min = fminf(fminf(r, g), b);
    float h, s, v = max;
    float d = max - min;
    s = max == 0 ? 0 : d / max;
    if (max == min) h = 0;
    else {
        if (max == r) h = (g - b) / d + (g < b ? 6 : 0);
        else if (max == g) h = (b - r) / d + 2;
        else h = (r - g) / d + 4;
        h /= 6;
    }
    return { h * 360.0f, s, v };
}

RGBQUAD HSVtoRGB(HSV hsv) {
    float r, g, b;
    int i = floor(hsv.h / 60.0f);
    float f = hsv.h / 60.0f - i;
    float p = hsv.v * (1 - hsv.s);
    float q = hsv.v * (1 - f * hsv.s);
    float t = hsv.v * (1 - (1 - f) * hsv.s);
    switch (i % 6) {
    case 0: r = hsv.v, g = t, b = p; break;
    case 1: r = q, g = hsv.v, b = p; break;
    case 2: r = p, g = hsv.v, b = t; break;
    case 3: r = p, g = q, b = hsv.v; break;
    case 4: r = t, g = p, b = hsv.v; break;
    case 5: r = hsv.v, g = p, b = q; break;
    }
    return { (BYTE)(b * 255), (BYTE)(g * 255), (BYTE)(r * 255), 0 };
}

// 1. Plasma & HSV Rotation (O efeito "fundo")
void PlasmaThread() {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    int ws = w / 4, hs = h / 4;
    HDC dc = GetDC(NULL);
    HDC dcCopy = CreateCompatibleDC(dc);
    BITMAPINFO bmpi = { 0 };
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = ws;
    bmpi.bmiHeader.biHeight = -hs;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    RGBQUAD* rgbquad;
    HBITMAP bmp = CreateDIBSection(dc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(dcCopy, bmp);

    float a = 5.0, b = 3.0;
    for (int i = 0;; i++) {
        HDC hdc = GetDC(NULL);
        StretchBlt(dcCopy, 0, 0, ws, hs, hdc, 0, 0, w, h, SRCCOPY);
        int randx = rand() % ws, randy = rand() % hs;

        for (int j = 0; j < ws * hs; j++) {
            int x = j % ws, y = j / ws;
            float zx = pow(x - randx, 2) / (a * a);
            float zy = pow(y - randy, 2) / (b * b);
            int fx = 128.0 + (128.0 * sin(sqrt(zx + zy) / 6.0));
            HSV hsv = RGBtoHSV(rgbquad[j]);
            hsv.h = fmod(fx + i, 360.0);
            rgbquad[j] = HSVtoRGB(hsv);
        }
        StretchBlt(hdc, 0, 0, w, h, dcCopy, 0, 0, ws, hs, SRCCOPY);
        ReleaseDC(NULL, hdc);
        Sleep(30);
    }
}

// 2. Melt & Jitter (O efeito de derretimento e tremor)
void DistortionThread() {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    while (true) {
        HDC hdc = GetDC(0);
        // Melt vertical
        int x = rand() % w;
        BitBlt(hdc, x, 1, 10, h, hdc, x, 0, SRCCOPY);
        // Tremor leve
        BitBlt(hdc, rand() % 3, rand() % 3, w, h, hdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(5);
    }
}

// 3. Strobe Invert (Inversão rítmica rápida)
void StrobeThread() {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    while (true) {
        HDC hdc = GetDC(0);
        PatBlt(hdc, 0, 0, w, h, PATINVERT);
        ReleaseDC(0, hdc);
        Sleep(150); // Pisca a cada 150ms
    }
}

// 4. Bouncing Ellipses (O rastro de bolas coloridas)
void BouncingThread() {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    int x = 10, y = 10, signX = 1, signY = 1, inc = 15;
    while (true) {
        HDC hdc = GetDC(0);
        x += inc * signX; y += inc * signY;
        HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
        SelectObject(hdc, brush);
        Ellipse(hdc, x, y, x + 120, y + 120);
        if (y >= h - 120 || y <= 0) signY *= -1;
        if (x >= w - 120 || x <= 0) signX *= -1;
        DeleteObject(brush);
        ReleaseDC(0, hdc);
        Sleep(15);
    }
}

int main() {
    // Ocultar console
    ShowWindow(GetConsoleWindow(), SW_HIDE);

    // Disparar todos os efeitos em paralelo
    std::thread t1(PlasmaThread);
    std::thread t2(DistortionThread);
    std::thread t3(StrobeThread);
    std::thread t4(BouncingThread);

    t1.join(); t2.join(); t3.join(); t4.join();
    return 0;
}

