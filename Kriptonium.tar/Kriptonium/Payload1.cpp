#include <windows.h>
#include <cmath>
#include <thread>
#include <vector>

// VARIABLES
int w, h;

// HSL structure
struct HSL { float h, s, l; };

float hue2rgb(float p, float q, float t) {
    if (t < 0.0f) t += 1.0f;
    if (t > 1.0f) t -= 1.0f;
    if (t < 1.0f / 6.0f) return p + (q - p) * 6.0f * t;
    if (t < 1.0f / 2.0f) return q;
    if (t < 2.0f / 3.0f) return p + (q - p) * (2.0f / 3.0f - t) * 6.0f;
    return p;
}

HSL RGBtoHSL(RGBQUAD rgb) {
    float r = rgb.rgbRed / 255.0f, g = rgb.rgbGreen / 255.0f, b = rgb.rgbBlue / 255.0f;
    float max = fmaxf(fmaxf(r, g), b), min = fminf(fminf(r, g), b);
    float h, s, l = (max + min) / 2.0f;
    if (max == min) h = s = 0.0f;
    else {
        float diff = max - min;
        s = (l > 0.5f) ? diff / (2.0f - max - min) : diff / (max + min);
        if (max == r) h = (g - b) / diff + (g < b ? 6.0f : 0.0f);
        else if (max == g) h = (b - r) / diff + 2.0f;
        else h = (r - g) / diff + 4.0f;
        h /= 6.0f;
    }
    return { h, s, l };
}

RGBQUAD HSLtoRGB(HSL hsl) {
    float r, g, b, q, p;
    if (hsl.s == 0.0f) r = g = b = hsl.l;
    else {
        q = (hsl.l < 0.5f) ? (hsl.l * (1.0f + hsl.s)) : (hsl.l + hsl.s - hsl.l * hsl.s);
        p = 2.0f * hsl.l - q;
        r = hue2rgb(p, q, hsl.h + 1.0f / 3.0f);
        g = hue2rgb(p, q, hsl.h);
        b = hue2rgb(p, q, hsl.h - 1.0f / 3.0f);
    }
    return { (BYTE)(b * 255), (BYTE)(g * 255), (BYTE)(r * 255), 0 };
}

// --- Shaders
void ShaderPayload() {
    HDC hdc, hdcCopy;
    hdc = GetDC(NULL);
    hdcCopy = CreateCompatibleDC(hdc);
    BITMAPINFO bmpi = { 0 };
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = w;
    bmpi.bmiHeader.biHeight = -h; // Top-down
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    RGBQUAD* rgbquad = NULL;
    HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hdcCopy, bmp);

    while (true) {
        hdc = GetDC(NULL);
        StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            HSL hsl = RGBtoHSL(rgbquad[i]);
            hsl.h = fmod(hsl.h + 0.01f, 1.0f);
            rgbquad[i] = HSLtoRGB(hsl);
        }
        StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
        ReleaseDC(NULL, hdc);
        Sleep(10);
    }
}

// --- Shake and Warp
void JitterWarpPayload() {
    while (true) {
        HDC hdc = GetDC(0);
        // Tremor
        BitBlt(hdc, rand() % 5, rand() % 5, w, h, hdc, rand() % 5, rand() % 5, SRCCOPY);
        // Warp (pequenas distorções)
        int size = rand() % 200;
        BitBlt(hdc, rand() % w, rand() % h, size, size, hdc, rand() % w, rand() % h, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(5);
    }
}

// TextOut
void TextPayload() {
    LOGFONTW lFont = { 0 };
    lFont.lfHeight = 50;
    lFont.lfWeight = FW_BOLD;
    lstrcpyW(lFont.lfFaceName, L"Arial Black");

    while (true) {
        HDC hdc = GetDC(NULL);
        SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        SetBkMode(hdc, TRANSPARENT);
        HFONT hFont = CreateFontIndirectW(&lFont);
        SelectObject(hdc, hFont);

        TextOutA(hdc, rand() % w, rand() % h, "OH NO", 5);

        DeleteObject(hFont);
        ReleaseDC(NULL, hdc);
        Sleep(100);
    }
}

int main() {
    ShowWindow(GetConsoleWindow(), SW_HIDE);

    // Inicializa dimensões
    w = GetSystemMetrics(SM_CXSCREEN);
    h = GetSystemMetrics(SM_CYSCREEN);

    std::thread t1(ShaderPayload);
    std::thread t2(JitterWarpPayload);
    std::thread t3(TextPayload);

    t1.join(); t2.join(); t3.join();

    return 0;
}
