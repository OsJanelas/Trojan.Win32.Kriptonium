#include <windows.h>
#include <thread>

// 1. Melt Reverso com Inversão (NOTSRCCOPY)
void ReverseMelt() {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    while (true) {
        HDC hdc = GetDC(0);
        int x = rand() % w;
        BitBlt(hdc, x, 1, 10, h, hdc, x, 0, NOTSRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(2);
    }
}

// 2. Flash Estroboscópico (PATINVERT)
void StrobeFlash() {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    while (true) {
        HDC hdc = GetDC(0);
        PatBlt(hdc, 0, 0, w, h, PATINVERT);
        ReleaseDC(0, hdc);
        Sleep(100);
    }
}

// 3. Tremor de Tela (Screen Jitter)
void ScreenJitter() {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    while (true) {
        HDC hdc = GetDC(0);
        // Deslocamento aleatório de até 10 pixels
        int x_off = rand() % 10;
        int y_off = rand() % 10;
        BitBlt(hdc, x_off, y_off, w, h, hdc, rand() % 10, rand() % 10, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}

// 4. Deslocamento Lateral (Screen Shifting)
void LateralShift() {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    while (true) {
        HDC hdc = GetDC(0);
        // Puxa a tela 30 pixels para a esquerda
        BitBlt(hdc, -30, 0, w, h, hdc, 0, 0, SRCCOPY);
        BitBlt(hdc, w - 30, 0, w, h, hdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}

// 5. Melt Simples (Colunas descendo)
void SimpleMelt() {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    while (true) {
        HDC hdc = GetDC(0);
        int rx = rand() % w;
        // Move uma coluna de 100px de largura para baixo
        BitBlt(hdc, rx, 10, 100, h, hdc, rx, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(5); // Adicionado um pequeno sleep para estabilidade
    }
}

int main() {
    // Esconder o console para efeito total
    ShowWindow(GetConsoleWindow(), SW_HIDE);

    // Lançando todas as payloads simultaneamente
    std::thread t1(ReverseMelt);
    std::thread t2(StrobeFlash);
    std::thread t3(ScreenJitter);
    std::thread t4(LateralShift);
    std::thread t5(SimpleMelt);

    // Aguardar as threads (loop infinito)
    t1.join(); t2.join(); t3.join(); t4.join(); t5.join();

    return 0;
}
